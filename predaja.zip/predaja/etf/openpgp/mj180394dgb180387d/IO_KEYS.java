package etf.openpgp.mj180394dgb180387d;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;

import org.bouncycastle.bcpg.ArmoredOutputStream;
import org.bouncycastle.openpgp.PGPException;
import org.bouncycastle.openpgp.PGPKeyRingGenerator;
import org.bouncycastle.openpgp.PGPPublicKey;
import org.bouncycastle.openpgp.PGPPublicKeyRing;
import org.bouncycastle.openpgp.PGPPublicKeyRingCollection;
import org.bouncycastle.openpgp.PGPSecretKey;
import org.bouncycastle.openpgp.PGPSecretKeyRing;
import org.bouncycastle.openpgp.PGPSecretKeyRingCollection;
import org.bouncycastle.openpgp.PGPUtil;
import org.bouncycastle.openpgp.operator.jcajce.JcaKeyFingerprintCalculator;

public class IO_KEYS {

    public static final void exportSecretKey(PGPKeyRingGenerator pgpKeyRingGen, File keyFile, boolean asciiArmor) throws IOException {
        PGPSecretKeyRing pgpSecKeyRing = pgpKeyRingGen.generateSecretKeyRing();
        FileOutputStream fos=new FileOutputStream(keyFile);
        ArmoredOutputStream ao=new ArmoredOutputStream(fos);
        if(asciiArmor) {
            pgpSecKeyRing.encode(ao);
        }
        else {
            pgpSecKeyRing.encode(new FileOutputStream(keyFile));
        }
        ao.close();
        fos.close();
    }
    public static final void exportSecretKey(PGPSecretKeyRing pgpSecretKeysRing, File keyFile, boolean asciiArmor) throws IOException {

        FileOutputStream fos=new FileOutputStream(keyFile);
        ArmoredOutputStream ao=new ArmoredOutputStream(fos);
        if(asciiArmor) {
            pgpSecretKeysRing.encode(ao);
        }
        else {
            pgpSecretKeysRing.encode(new FileOutputStream(keyFile));
        }
        ao.close();
        fos.close();
    }
    public static final void exportSecretKey(PGPSecretKey pgpSecretKey, File keyFile, boolean asciiArmor) throws IOException {
        FileOutputStream fos=new FileOutputStream(keyFile);
        ArmoredOutputStream ao=new ArmoredOutputStream(fos);
        if(asciiArmor) {
            pgpSecretKey.encode(ao);
        }
        else {
            pgpSecretKey.encode(new FileOutputStream(keyFile));
        }
        ao.close();
        fos.close();
    }


    public static final void exportPublicKey(PGPKeyRingGenerator pgpKeyRingGen, File keyFile, boolean asciiArmor) throws IOException {
        //   PGPPublicKeyRing pgpPubKeyRing = pgpKeyRingGen.generatePublicKeyRing();
        PGPPublicKeyRing pgpSecKeyRing = pgpKeyRingGen.generatePublicKeyRing();
        FileOutputStream fos=new FileOutputStream(keyFile);
        ArmoredOutputStream ao=new ArmoredOutputStream(fos);
        if(asciiArmor) {
            pgpSecKeyRing.encode(ao);
        }
        else {
            pgpSecKeyRing.encode(new FileOutputStream(keyFile));
        }
        ao.close();
        fos.close();
    }
    public static final void exportPublicKey(PGPPublicKeyRing pgpPublicKeyRing, File keyFile, boolean asciiArmor) throws IOException {
     //   PGPPublicKeyRingCollection pcol=new PGPPublicKeyRingCollection();
        FileOutputStream fos=new FileOutputStream(keyFile);
        ArmoredOutputStream ao=new ArmoredOutputStream(fos);
        if(asciiArmor) {
            pgpPublicKeyRing.encode(ao);
        }
        else {
            pgpPublicKeyRing.encode(new FileOutputStream(keyFile));
        }
        ao.close();
        fos.close();
    }
    public static final void exportPublicKey(PGPPublicKey pgpPublic, File keyFile, boolean asciiArmor) throws IOException {

        FileOutputStream fos=new FileOutputStream(keyFile);
        ArmoredOutputStream ao=new ArmoredOutputStream(fos);
        if(asciiArmor) {
            pgpPublic.encode(ao);

        }
        else {
            pgpPublic.encode(new FileOutputStream(keyFile));
        }
        ao.close();
        fos.close();
    }



    public static Iterator<PGPPublicKeyRing> readPublicKeysFromFile(File file) throws IOException, PGPException {
        InputStream input=new FileInputStream(file);
        PGPPublicKeyRingCollection pgpPub = new PGPPublicKeyRingCollection(PGPUtil.getDecoderStream(input), new JcaKeyFingerprintCalculator());

        return pgpPub.getKeyRings();


    }

    public static Iterator<PGPSecretKeyRing> readSecretKeysFromFile(File file) throws IOException, PGPException {
        InputStream input=new FileInputStream(file);
        PGPSecretKeyRingCollection pgpPub = new PGPSecretKeyRingCollection(PGPUtil.getDecoderStream(input), new JcaKeyFingerprintCalculator());

        return pgpPub.getKeyRings();
//        Iterator<PGPPublicKeyRing> keyRingIter = pgpPub.getKeyRings();
    }



}
