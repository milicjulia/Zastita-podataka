package etf.openpgp.mj180394dgb180387d.GUI;

import etf.openpgp.mj180394dgb180387d.Generate_Key_RingG;
import etf.openpgp.mj180394dgb180387d.KEYS;
import org.bouncycastle.openpgp.PGPKeyRingGenerator;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class genKeyDialog {
    private JDialog frame;
    private JTextField namet, mailt, passwordt;
    private JPanel panel, dsap, elgamalp, parent;
    private JLabel dsal, elgamall, namel, maill, passwordl;
    private ButtonGroup dsag, elgamalg;
    private JRadioButton i11, i12, i21, i22, i23;
    private JButton add, pass;
    private JScrollPane jsp;
    private MainFrame mf;

    public genKeyDialog(JPanel parent, JScrollPane jsp, MainFrame mf){
    	this.mf=mf;
    	this.jsp=jsp;
    	this.parent=parent;
        frame = new JDialog();
        frame.setSize(350, 200);
        addComponents();
        frame.setVisible(true);
    }

    public void addComponents(){
        addData();
        addRadio();
        addButton();
        addPanel();
        frame.add(panel);
    }

    public void addButton(){
        add=new JButton("Dodaj");
        add.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(mailt.getText().compareTo("")!=0 && namet.getText().compareTo("")!=0){
                    addPassword();
                }
            }
        });
    }

    public void addPassword(){
        frame.remove(panel);
        frame.setSize(250, 130);
        frame.setVisible(true);
        panel=new JPanel(new GridLayout(0,1));
        passwordl=new JLabel("Password: ");
        passwordt=new JTextField();
        pass=new JButton("Zavrsi");
        pass.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(passwordt.getText().compareTo("")!=0 && mailt.getText().compareTo("")!=0 && namet.getText().compareTo("")!=0 && (i11.isSelected() || i12.isSelected()) && (i21.isSelected() || i22.isSelected() || i23.isSelected())){
                    String identity= namet.getText()+";"+mailt.getText();
                    int dsa, elgamal;
                    if(i11.isSelected()) dsa=1024; else dsa=2048;
                    if(i21.isSelected()) elgamal=1024; else if(i22.isSelected()) elgamal=2048; else elgamal=4096;
                    try {
                        PGPKeyRingGenerator pgp_ring_gen= Generate_Key_RingG.createPGPKeyRingGenerator(dsa,elgamal,identity,passwordt.getText().toCharArray());
                        KEYS.my_publicKeys.add(pgp_ring_gen.generatePublicKeyRing());

                        KEYS.my_secretKeys.add(pgp_ring_gen.generateSecretKeyRing());
                        KEYS.saveKeys();
                        parent.remove(jsp);
                        mf.addData();
                        parent.repaint();
                        parent.revalidate();
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                    frame.setVisible(false);
                    frame.dispose();
                }
            }
        });
        panel.add(passwordl);
        panel.add(passwordt);
        panel.add(pass);
        panel.setVisible(true);
        frame.add(panel);
    }

    public void addData(){
        namel=new JLabel("Name: ");
        namet=new JTextField();
        maill=new JLabel("Mail: ");
        mailt=new JTextField();
    }

    public void addRadio(){
        dsap = new JPanel(new GridLayout(0,2));
        elgamalp = new JPanel(new GridLayout(0,3));
        dsal=new JLabel("DSA:");
        elgamall=new JLabel("ElGamal:");
        dsag=new ButtonGroup();
        elgamalg=new ButtonGroup();
        i11=new JRadioButton("1024", true);
        i12=new JRadioButton("2048");
        i21=new JRadioButton("1024", true);
        i22=new JRadioButton("2048");
        i23=new JRadioButton("4096");
        dsag.add(i11);
        dsag.add(i12);
        elgamalg.add(i21);
        elgamalg.add(i22);
        elgamalg.add(i23);
        dsap.add(i11);
        dsap.add(i12);
        elgamalp.add(i21);
        elgamalp.add(i22);
        elgamalp.add(i23);
        dsap.setVisible(true);
        elgamalp.setVisible(true);
    }

    public void addPanel(){
        panel = new JPanel();
        panel.setLayout(new GridLayout(0,2));
        panel.add(namel);
        panel.add(namet);
        panel.add(maill);
        panel.add(mailt);
        panel.add(dsal);
        panel.add(elgamall);
        panel.add(dsap);
        panel.add(elgamalp);
        panel.add(add);
        panel.setVisible(true);
    }
}
