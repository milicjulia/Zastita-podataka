package etf.openpgp.mj180394dgb180387d.GUI;

import etf.openpgp.mj180394dgb180387d.KEYS;
import org.bouncycastle.openpgp.PGPException;
import org.bouncycastle.openpgp.PGPPublicKey;
import org.bouncycastle.openpgp.PGPSecretKey;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class delKeyDialog {
    private JDialog frame;
    private JTextField passwordt;
    private JPanel panel, parent;
    private JLabel passwordl;
    private JButton pass;
    private PGPSecretKey secretKeyByID;
    private PGPPublicKey publicKeyByID;
    private MainFrame mf;
    private JScrollPane jsp;

    public delKeyDialog(String id, String tip, JPanel panel, JScrollPane jsp, MainFrame mf){
    	this.parent=panel;
    	this.jsp=jsp;
    	this.mf=mf;
        if(tip.compareTo("secret key")!=0) {
            publicKeyByID = KEYS.findPublicKeyByID(Long.parseUnsignedLong(id,16));
            if(tip.compareTo("other key")!=0) {
                KEYS.deleteOtherKey(publicKeyByID);
                mf.greska.setText("Obrisan other kljuc");
                try {
					KEYS.saveKeys();
				} catch (IOException | PGPException e) {
					e.printStackTrace();
				}
            }
            else {
              //  KEYS.deletePublicKey(publicKeyByID);
                mf.greska.setText("Ne mozete obrisati korisnikov javni kljuc");
            }
            parent.remove(jsp);
            mf.addData();
            mf.refreshFrame();
        }
        else{
            secretKeyByID = KEYS.findSecretKeyByID(Long.parseUnsignedLong(id,16));
            frame = new JDialog();
            frame.setSize(250, 130);
            addPassword();
            frame.setVisible(true);
        }
    }

    public void saveKeys(){
        try {
            KEYS.saveKeys();
            frame.setVisible(false);
            frame.dispose();
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (PGPException ex) {
            ex.printStackTrace();
        }
    }


    public void addPassword(){
        panel=new JPanel(new GridLayout(0,1));
        passwordl=new JLabel("Password: ");
        passwordt=new JTextField();
        pass=new JButton("Zavrsi");
        pass.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(KEYS.getPrivateKeyFromSecretKey(secretKeyByID,passwordt.getText().toCharArray())!=null){
                   KEYS.deletePrivateKey(secretKeyByID,passwordt.getText().toCharArray());
                   mf.greska.setText("Obrisan privatni kljuc");
                   saveKeys();
                   parent.remove(jsp);
                   mf.addData();
                }
                else mf.greska.setText("Neuspesno obrisan privatni kljuc");
                parent.repaint();
                parent.revalidate();
            }
        });
        panel.add(passwordl);
        panel.add(passwordt);
        panel.add(pass);
        panel.setVisible(true);
        frame.add(panel);
    }

}
