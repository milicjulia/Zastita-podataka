package etf.openpgp.mj180394dgb180387d.GUI;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.filechooser.FileSystemView;
import org.bouncycastle.openpgp.PGPException;
import org.bouncycastle.openpgp.PGPPublicKeyRing;
import org.bouncycastle.openpgp.PGPSecretKeyRing;
import etf.openpgp.mj180394dgb180387d.IO_KEYS;
import etf.openpgp.mj180394dgb180387d.KEYS;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.Iterator;

public class importKey {
	private JFileChooser bira;
	private FileNameExtensionFilter filter;
	private String putanja;
	private JDialog d;
	private JButton pub, priv;
	private JScrollPane jsp;
	private MainFrame mf;
	private JPanel parent, sve;

	public importKey(JPanel parent, JScrollPane jsp, MainFrame mf) {
		this.d = new JDialog();
		d.setTitle("Uvoz kljuca");
		d.setSize(300, 300);
		sve = new JPanel(new GridLayout(1, 2));
		d.setVisible(true);
		this.mf = mf;
		this.jsp = jsp;
		this.parent = parent;
		d.setTitle("Uvoz kljuca");
		pub = new JButton("Uvezi javni kljuc");
		priv = new JButton("Uvezi privatni kljuc");
		sve.add(pub);
		sve.add(priv);
		sve.setVisible(true);
		d.add(sve);
		pub.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				addFile(1);

			}
		});

		priv.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				addFile(0);

			}
		});

	}

	public void addFile(int tip) {
		boolean izabrao = false;
		while (!izabrao) {
			bira = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
			bira.setDialogTitle("Uvoz kljuca");
			bira.setAcceptAllFileFilterUsed(false);
			filter = new FileNameExtensionFilter(".asc", "asc");
			bira.addChoosableFileFilter(filter);

			if (bira.showOpenDialog(d) == JFileChooser.APPROVE_OPTION) {
				putanja = bira.getSelectedFile().getPath();
				try {
					if (tip == 0) {
						Iterator<PGPSecretKeyRing> p = IO_KEYS.readSecretKeysFromFile(new File(putanja));
						PGPSecretKeyRing n = p.next();
						KEYS.my_secretKeys.add(n);
					} else {
						Iterator<PGPPublicKeyRing> p = IO_KEYS.readPublicKeysFromFile(new File(putanja));
						// PGPPublicKeyRing p = IO_KEYS.readPublicKeyFromFile(new File(putanja));
						PGPPublicKeyRing n = p.next();
						// PGPPublicKeyRing n=p;
						KEYS.other_publicKeys.add(n);
					}
					KEYS.saveKeys();
					parent.remove(jsp);
					mf.addData();
					parent.repaint();
					parent.revalidate();
					d.dispose();

					izabrao = true;

				} catch (IOException | PGPException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			} else if (bira.showOpenDialog(d) == JFileChooser.CANCEL_OPTION) {
				izabrao = true;
			}

		}
	}
}
