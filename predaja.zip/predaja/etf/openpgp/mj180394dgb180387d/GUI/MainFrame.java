package etf.openpgp.mj180394dgb180387d.GUI;

import etf.openpgp.mj180394dgb180387d.KEYS;
import org.bouncycastle.openpgp.PGPException;
import org.bouncycastle.openpgp.PGPPublicKey;
import org.bouncycastle.openpgp.PGPSecretKey;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;

public class MainFrame {
	private MainFrame ja = this;
	private JFrame frame;
	private JMenuBar mb;
	private JMenu m1;
	private JMenuItem m11, m12, m2, m3, m4, m5;
	private JPanel panel;
	private DefaultTableModel model;
	private JTable tabela;
	private JScrollPane jsp;
	public JLabel greska;

	public MainFrame() throws PGPException, IOException {
		greska = new JLabel();
		greska.setText("");
		KEYS.loadKeys();
		frame = new JFrame("Zastita podataka");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(800, 800);
		addMenuBar();
		addPanel();
		addData();
	}

	public void addMenuKey() {
		m1 = new JMenu("Rad sa kljucem");
		m11 = new JMenuItem("Generisi kljuc");
		m11.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new genKeyDialog(panel, jsp, ja);
				refreshFrame();

			}
		});
		m12 = new JMenuItem("Brisi kljuc");
		m12.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int sel = tabela.getSelectedRow();
				if (sel != -1) {
					String tipKljuca = tabela.getValueAt(sel, 4).toString();
					String idK = tabela.getValueAt(sel, 3).toString();
					new delKeyDialog(idK, tipKljuca, panel, jsp, ja);
					greska.setText("");

				} else {
					greska.setText("Morate selektovati kljuc da bi uradili brisanje");
				}
				refreshFrame();
			}
		});
		m1.add(m11);
		m1.add(m12);
		mb.add(m1);
	}

	public void addMenuSendMessage() {
		m2 = new JMenuItem("Slanje poruke");
		m2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new sendMessage();
			}
		});
		mb.add(m2);
	}

	public void addMenuGetMessage() {
		m3 = new JMenuItem("Primanje poruke");
		m3.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new getMessage();
			}
		});
		mb.add(m3);
	}

	public void addMenuImportKey() {
		m4 = new JMenuItem("Uvezi kljuc");
		m4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new importKey(panel, jsp, ja);
				refreshFrame();
			}
		});
		mb.add(m4);
	}

	public void addMenuExportKey() {
		m5 = new JMenuItem("Izvezi kljuc");
		m5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int rrow = tabela.getSelectedRow();
				if (rrow != -1) {
					String id = tabela.getValueAt(rrow, 3).toString();
					int tipK = tabela.getValueAt(rrow, 4).toString().compareTo("secret key") == 0 ? 0 : 1;
					new exportKey(id, tipK, new JFrame());
					greska.setText("");
				} else {
					greska.setText("Morate selektovati kljuc da bi uradili export");
				}
				refreshFrame();
			}
		});
		mb.add(m5);
	}

	public void addMenuBar() {
		mb = new JMenuBar();
		addMenuKey();
		addMenuSendMessage();
		addMenuGetMessage();
		addMenuImportKey();
		addMenuExportKey();
	}

	public void refreshFrame() {
		frame.repaint();
		frame.revalidate();
		frame.setVisible(true);
	}

	public void addPanel() {
		panel = new JPanel();
		panel.setSize(frame.getWidth(), frame.getHeight());
		frame.getContentPane().add(BorderLayout.CENTER, panel);
		frame.getContentPane().add(BorderLayout.NORTH, mb);
		frame.getContentPane().add(BorderLayout.SOUTH, greska);
		frame.setVisible(true);
		frame.repaint();
		frame.revalidate();
	}

	@SuppressWarnings("serial")
	public void addData() {
		ArrayList<PGPPublicKey> other_keys = KEYS.get_other_keys();
		ArrayList<PGPSecretKey> secret_keys = KEYS.get_sign_keys();
		ArrayList<PGPPublicKey> public_keys = KEYS.get_public_keys();
		String[] colName = { "Kljuc", "Id", "Vreme", "Kljuc id", "Tip" };
		model = new DefaultTableModel(colName, 0);
		tabela = new JTable(model){
			    @Override
			       public Component prepareRenderer(TableCellRenderer renderer, int row, int column) {
			           Component component = super.prepareRenderer(renderer, row, column);
			           int rendererWidth = component.getPreferredSize().width;
			           TableColumn tableColumn = getColumnModel().getColumn(column);
			           tableColumn.setPreferredWidth(Math.max(rendererWidth + getIntercellSpacing().width+15, tableColumn.getPreferredWidth()));
			           return component;
			        }
			    };
			tabela.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		int i = 0;
		for (i = 0; i < secret_keys.size(); i++) {
			model.addRow(
					new Object[] { 
							"Kljuc" + i,
							secret_keys.get(i).getUserIDs().hasNext() ? secret_keys.get(i).getUserIDs().next() : "",
							secret_keys.get(i).getPublicKey().getCreationTime().toString(),
							Long.toHexString(secret_keys.get(i).getKeyID()), "secret key" 
							}
					);

		}
		int j = i;
		for (i = 0; i < other_keys.size(); i++) {
			model.addRow(
					new Object[] { 
							"Kljuc" + j++,
							other_keys.get(i).getUserIDs().hasNext() ? other_keys.get(i).getUserIDs().next() : "",
							other_keys.get(i).getCreationTime().toString(), Long.toHexString(other_keys.get(i).getKeyID()),
							"other key" 
							}
					);
		}
		int jj = j;
		for (i = 0; i < public_keys.size(); i++) {
			model.addRow(
					new Object[] { 
							"Kljuc" + jj++,
							public_keys.get(i).getUserIDs().hasNext() ? public_keys.get(i).getUserIDs().next() : "",
							public_keys.get(i).getCreationTime().toString(), Long.toHexString(public_keys.get(i).getKeyID()),
							"public key" 
							}
					);
		}

		jsp = new JScrollPane(tabela);
		jsp.setPreferredSize(new Dimension(frame.getWidth()-100,frame.getHeight()));
		model.fireTableDataChanged();
		panel.add(jsp);
		panel.revalidate();
		panel.repaint();
		panel.setVisible(true);
		frame.setVisible(true);
		frame.repaint();
		frame.revalidate();
	}

	public static void main(String args[]) throws PGPException, IOException {
		new MainFrame();
	}

}
