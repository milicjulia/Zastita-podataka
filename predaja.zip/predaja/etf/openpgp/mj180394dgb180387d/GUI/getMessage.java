package etf.openpgp.mj180394dgb180387d.GUI;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.SignatureException;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.filechooser.FileNameExtensionFilter;

import org.bouncycastle.openpgp.PGPException;

import etf.openpgp.mj180394dgb180387d.Decrypt;

public class getMessage {
	private JDialog dialog;
	private JButton biraj;
	private JPanel all, poruka;
	private String path;
	private File file;
	private JFileChooser f;

	public getMessage() {
		dialog = new JDialog();
		dialog.setTitle("Get message");
		dialog.setSize(400, 300);
		dialog.setVisible(true);
		all = new JPanel();
		biraj = new JButton("Izaberite OpenPGP file");
		biraj.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				chooseFile();
				unosLozinke();
			}
		});
		all.add(biraj);
		poruka = new JPanel(new GridLayout(0, 1));
		all.add(poruka);
		all.setVisible(true);
		dialog.add(all);
	}

	public void chooseFile() {
		f = new JFileChooser();
		f.setDialogTitle("Izaberite fajl za unos");
		f.setFileSelectionMode(JFileChooser.FILES_ONLY);
		f.addChoosableFileFilter(new FileNameExtensionFilter("OpenPGP", "pgp"));
		f.setAcceptAllFileFilterUsed(true);

		int result = f.showSaveDialog(dialog);
		if (result == JFileChooser.APPROVE_OPTION) {
			file = f.getSelectedFile();
			path = file.getAbsolutePath();
			//System.out.println(path);
		}

	}

	public void unosLozinke() {
		Dimension d = new Dimension(70, 25);
		JDialog jd = new JDialog(this.dialog);
		jd.setSize(300, 200);
		jd.setTitle("Unos lozinke");
		JTextArea txt = new JTextArea();
		JLabel l = new JLabel("Unesite lozinku");
		JButton b = new JButton("Potvrdite lozinku");
		b.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				ArrayList<String> poruke = new ArrayList<>();
				try {
					poruke = Decrypt.decryptAndVerify(new FileInputStream(path),new FileOutputStream(new File("izlaz1234.txt")), txt.getText().toCharArray());
				} catch (SignatureException | IOException | PGPException e1) {
					e1.printStackTrace();
				}

				//if (txt.getText().compareTo("pass") == 0) {
					jd.dispose();
					for (String l : poruke)
						all.add(new JLabel(l));
					all.setVisible(true);
					dialog.setVisible(true);
				//}
			}
		});
		txt.setSize(d);
		l.setSize(d);
		b.setSize(d);
		JPanel p = new JPanel(new GridLayout(3, 1));
		p.add(l);
		p.add(txt);
		p.add(b);
		p.setVisible(true);
		jd.add(p, BorderLayout.CENTER);
		jd.setVisible(true);
	}

	

}
