package etf.openpgp.mj180394dgb180387d.GUI;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.filechooser.FileSystemView;

import org.bouncycastle.openpgp.PGPPublicKeyRing;
import org.bouncycastle.openpgp.PGPSecretKeyRing;
import etf.openpgp.mj180394dgb180387d.IO_KEYS;
import etf.openpgp.mj180394dgb180387d.KEYS;
import java.io.File;
import java.io.IOException;

public class exportKey {
	private JFrame mf;
	private PGPSecretKeyRing secretKeyByID;
	private PGPPublicKeyRing publicKeyByID;
	private int tip;

	public exportKey(String id, int tip, JFrame mf) { // dodati u konstruktoru kljuc
		this.mf = mf;
		this.tip = tip;
		if (tip == 0) secretKeyByID = KEYS.getSecretKeyRing(Long.parseUnsignedLong(id, 16));
		else publicKeyByID = KEYS.getPublicKeyRing(Long.parseUnsignedLong(id, 16));
		addKey();
	}

	public void addKey() {
		boolean izabran = false;
		while (!izabran) {
			JFileChooser bira = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
			bira.setDialogTitle("Izaberite gde exportujete kljuc i dajte naziv");
			bira.setAcceptAllFileFilterUsed(false);
			FileNameExtensionFilter filter = new FileNameExtensionFilter(".asc", "asc");
			bira.addChoosableFileFilter(filter);
			if (bira.showSaveDialog(mf) == JFileChooser.SAVE_DIALOG) {
				String putanja = bira.getSelectedFile().getPath();
				izabran = true;
				try {
					File file=new File(putanja + ".asc");
					if (tip == 0) IO_KEYS.exportSecretKey(secretKeyByID,file , true);
					else IO_KEYS.exportPublicKey(publicKeyByID, file, true);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				mf.dispose();
			} else if (bira.showSaveDialog(mf) == JFileChooser.CANCEL_OPTION) {
				izabran = true;
				mf.dispose();
			}
		}

	}
}
