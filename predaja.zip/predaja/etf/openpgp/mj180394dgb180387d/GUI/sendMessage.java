package etf.openpgp.mj180394dgb180387d.GUI;

import etf.openpgp.mj180394dgb180387d.Encrypt;
import etf.openpgp.mj180394dgb180387d.KEYS;

import org.bouncycastle.openpgp.PGPPrivateKey;
import org.bouncycastle.openpgp.PGPPublicKey;
import org.bouncycastle.openpgp.PGPSecretKey;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.filechooser.FileSystemView;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class sendMessage {
	private JDialog frame;
	private JCheckBox izbor[];
	private JPanel svi, izbori, ostalo[], ostalosvi;
	private ArrayList<PGPSecretKey> sviPrivatniKljucevi;
	private ArrayList<PGPPublicKey> sviJavniKljucevi;
	private DefaultTableModel model1, model2;
	private JTable tabela1, tabela2;
	private ButtonGroup btg;
	private JRadioButton bt[];
	private int[] selectedRows;
	private int row;
	private JLabel lozinkalbl, greska;
	private JTextField lozinkatxt;
	private JButton lozinkabtn;
	private PGPPrivateKey privatniKljuc;
	private PGPPublicKey publickeys[];
	private JButton savesve;

	public sendMessage() {
		greska = new JLabel("");
		frame = new JDialog();
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.setTitle("Slanje poruke");
		frame.setSize(900, 700);
		addPosalji();
		addPanels();
		addChoice();
		addData0();
		addData1();
		frame.add(svi);
		frame.setVisible(true);

	}

	public void addPanels() {
		GridBagConstraints c = new GridBagConstraints();
		svi = new JPanel();
		izbori = new JPanel(new GridLayout(4, 1));
		
		c.fill=GridBagConstraints.HORIZONTAL;
		c.weightx = 0.0;
		ostalo = new JPanel[2];
		ostalosvi = new JPanel(new GridLayout(1,2,50,2));
		c.gridx = 1;
		c.gridy = 1;
		svi.add(izbori, c);
		for (int i = 0; i < 2; i++) {
			ostalo[i] = new JPanel(new BorderLayout());
			//ostalo[i].setSize(ostalosvi.getWidth(), ostalosvi.getHeight()/2);
			ostalosvi.add(ostalo[i]);
			ostalo[i].setVisible(false);
		}
		c.gridwidth = 5;
		c.gridheight = 2;
		c.gridx = 0;
		c.gridy = 1;
		svi.add(ostalosvi, c);
		c.gridwidth = 5;
		c.gridx = 3;
		c.gridy = 4;
		c.gridheight = 1;
		svi.add(savesve, c);
		c.gridx = 3;
		c.gridy = 5;
		c.gridwidth = 5;
		c.gridheight = 1;
		svi.add(greska, c);
	}

	public void addPosalji() {
		savesve = new JButton("Posalji poruku");
		savesve.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				sacuvam();
			}
		});
	}

	public void sacuvam() {
		boolean mozedalje = true;
		if (izbor[0].isSelected()) {
			selectedRows = tabela2.getSelectedRows();
			if (selectedRows == null || selectedRows.length == 0) {
				mozedalje = false;
			} else {
				mozedalje = true;
				publickeys = new PGPPublicKey[selectedRows.length];
				for (int i = 0; i < selectedRows.length; i++) {
					publickeys[i] = KEYS.findPublicKeyByID(Long.parseUnsignedLong(tabela2.getValueAt(selectedRows[i], 3).toString(), 16));
				}
			}
		}
		if (izbor[1].isSelected() && mozedalje) {
			row = tabela1.getSelectedRow();
			if (row == -1) {
				mozedalje = false;
			} else {
				if (privatniKljuc == null)
					mozedalje = false;
				else
					mozedalje = true;
			}
		}
		if (mozedalje) {
			int status = 0;
			if (izbor[0].isSelected()) {
				status |= Encrypt.ENCRYPT_FLAG;
				if (bt[0].isSelected())
					status |= Encrypt.IDEA_ENCRYPT_FLAG;
				else
					status |= Encrypt.TRIPLE_DES_ENCRYPT_FLAG;
			}
			if (izbor[1].isSelected()) {
				status |= Encrypt.SIGN_FLAG;
			}
			if (izbor[2].isSelected()) {
				status |= Encrypt.COMPRESS_FLAG;
			}
			if (izbor[3].isSelected()) {
				status |= Encrypt.RADIX64_FLAG;
			}
			try {
				chooseFile(status);

			} catch (Exception e1) {
				e1.printStackTrace();
			}

		} else {
			greska.setText("Niste popunili sve podatke");
			greska.setVisible(true);
		}
	}

	public void chooseFile(int status) throws Exception {
		boolean izabran = false;
		while (!izabran) {
			JFileChooser bira = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
			bira.setDialogTitle("Izaberite poruku koju saljete");
			bira.setAcceptAllFileFilterUsed(false);
			FileNameExtensionFilter filter = new FileNameExtensionFilter(".txt", "txt");
			bira.addChoosableFileFilter(filter);
			if (bira.showOpenDialog(frame) == JFileChooser.APPROVE_OPTION) {
				String putanja = bira.getSelectedFile().getPath();
				izabran = true;
				saveFile(putanja, status);
			} 
			else if (bira.showOpenDialog(frame) == JFileChooser.CANCEL_OPTION) {
				izabran=true;
				frame.dispose();
			}
		}
	}

	public void saveFile(String fajl, int status) throws Exception {
		boolean izabran = false;
		while (!izabran) {
			JFileChooser bira = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
			bira.setDialogTitle("Izaberite mesto cuvanja");
			bira.setAcceptAllFileFilterUsed(false);
			FileNameExtensionFilter filter = new FileNameExtensionFilter(".pgp", "pgp");
			bira.addChoosableFileFilter(filter);
			if (bira.showSaveDialog(frame) == JFileChooser.SAVE_DIALOG) {
				String putanja = bira.getSelectedFile().getPath();
				Encrypt.signEncryptFile(fajl, publickeys[0], sviPrivatniKljucevi.get(row),lozinkatxt.getText().toCharArray(), status, putanja);
				izabran = true;
				frame.dispose();
			} else if (bira.showOpenDialog(frame) == JFileChooser.CANCEL_OPTION) {
				izabran=true;
				frame.dispose();
			}
		}
	}

	@SuppressWarnings("serial")
	public void addData0() {
		JLabel l = new JLabel("Izaberite 1 ili vise javnih kljuceva za enkripciju i algoritam");
		JPanel pom = new JPanel(new GridLayout(1, 2));
		btg = new ButtonGroup();
		bt = new JRadioButton[2];
		for (int i = 0; i < 2; i++) {
			bt[i] = new JRadioButton();
			btg.add(bt[i]);
		}
		bt[0].setText("IDEA");
		bt[1].setText("3DES");
		bt[0].setSelected(true);
		
		sviJavniKljucevi = KEYS.get_other_keys();
		String[] colName = { "Kljuc", "Id", "Vreme", "Kljuc id", "Tip" };
		model2 = new DefaultTableModel(colName, 0);
		tabela2 = new JTable(model2){
		    @Override
		       public Component prepareRenderer(TableCellRenderer renderer, int row, int column) {
		           Component component = super.prepareRenderer(renderer, row, column);
		           int rendererWidth = component.getPreferredSize().width;
		           TableColumn tableColumn = getColumnModel().getColumn(column);
		           tableColumn.setPreferredWidth(Math.max(rendererWidth + getIntercellSpacing().width+15, tableColumn.getPreferredWidth()));
		           return component;
		        }
		    };
		tabela2.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		for (int i = 0; i < sviJavniKljucevi.size(); i++) {
			model2.addRow(
					new Object[] { 
							"Kljuc" + i,
							sviJavniKljucevi.get(i).getUserIDs().hasNext() ? sviJavniKljucevi.get(i).getUserIDs().next(): "",
							sviJavniKljucevi.get(i).getCreationTime().toString(),
							Long.toHexString(sviJavniKljucevi.get(i).getKeyID()), "public key" 
							}
					);
		}
		JScrollPane jsp = new JScrollPane(tabela2);
		jsp.setPreferredSize(new Dimension(frame.getWidth()/2-50,model2.getRowCount()*25));
		
		ostalo[0].add(l, BorderLayout.PAGE_START);
		ostalo[0].add(jsp,BorderLayout.CENTER);
		pom.add(bt[0]);
		pom.add(bt[1]);
		ostalo[0].add(pom, BorderLayout.PAGE_END);
		ostalo[0].setVisible(false);
	}

	@SuppressWarnings("serial")
	public void addData1() {
		JPanel lozinkaprovera = new JPanel(new GridLayout(3, 1));
		JLabel l = new JLabel("Izaberite privatni kljuc za potpis");
		lozinkalbl = new JLabel();
		lozinkalbl.setText("Lozinka");
		lozinkabtn = new JButton();
		lozinkabtn.setText("Potvrdi lozinku");
		lozinkatxt = new JTextField();
		lozinkaprovera.add(lozinkalbl);
		lozinkaprovera.add(lozinkatxt);
		lozinkaprovera.add(lozinkabtn);
		lozinkaprovera.setVisible(true);
		lozinkaprovera.setSize(ostalo[1].getWidth(), 150);
		ostalo[1].add(lozinkaprovera, BorderLayout.SOUTH);
		
		sviPrivatniKljucevi = KEYS.get_sign_keys();
		String[] colName = { "Kljuc", "Id", "Vreme", "Kljuc id", "Tip" };
		model1 = new DefaultTableModel(colName, 0);
		tabela1 = new JTable(model1){
		    @Override
		       public Component prepareRenderer(TableCellRenderer renderer, int row, int column) {
		           Component component = super.prepareRenderer(renderer, row, column);
		           int rendererWidth = component.getPreferredSize().width;
		           TableColumn tableColumn = getColumnModel().getColumn(column);
		           tableColumn.setPreferredWidth(Math.max(rendererWidth + getIntercellSpacing().width+15, tableColumn.getPreferredWidth()));
		           return component;
		        }
		    };
		tabela1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		for (int i = 0; i < sviPrivatniKljucevi.size(); i++) {
			model1.addRow(
					new Object[] { 
							"Kljuc" + i, 
							sviPrivatniKljucevi.get(i).getUserIDs().next(),
							sviPrivatniKljucevi.get(i).getPublicKey().getCreationTime().toString(),
							Long.toHexString(sviPrivatniKljucevi.get(i).getKeyID()), "secret key" 
							}
					);
		}
		tabela1.addMouseListener(new MouseListener() {
			@Override
			public void mouseClicked(MouseEvent e) {
				lozinkatxt.setText("");
				privatniKljuc = null;
				greska.setText("");
				lozinkaprovera.setVisible(true);
				JTable jt = (JTable) e.getSource();
				row = jt.rowAtPoint(e.getPoint());
				lozinkabtn.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						privatniKljuc = KEYS.getPrivateKeyFromSecretKey(sviPrivatniKljucevi.get(row),lozinkatxt.getText().toCharArray());
						if (privatniKljuc == null) {
							greska.setText("Lozinka ne odgovara");
						} else
							greska.setText("");
						ostalo[1].repaint();
						ostalo[1].revalidate();
					}
				});
				ostalo[1].repaint();
				ostalo[1].revalidate();
			}

			@Override
			public void mousePressed(MouseEvent e) {}

			@Override
			public void mouseReleased(MouseEvent e) {}

			@Override
			public void mouseEntered(MouseEvent e) {}

			@Override
			public void mouseExited(MouseEvent e) {}
		});
		
		
		JScrollPane jsp = new JScrollPane(tabela1);
		jsp.setPreferredSize(new Dimension(frame.getWidth()/2-50,model1.getRowCount()*25));
		
		ostalo[1].add(l, BorderLayout.NORTH);
		ostalo[1].add(jsp, BorderLayout.CENTER);
		ostalo[1].repaint();
		ostalo[1].revalidate();
		ostalo[1].setVisible(false);
	}

	public void addChoice() {
		izbor = new JCheckBox[4];
		int i = 0;
		for (i = 0; i < 4; i++) {
			izbor[i] = new JCheckBox();
			izbor[i].setSelected(false);
			switch (i) {
				case 0: {
					izbor[i].setText("Enkripcija poruke za obezbedjivanje tajnosti");
					break;
				}
				case 1: {
					izbor[i].setText("Potpisivanje za obezbedjivanje autenticnosti");
					break;
				}
				case 2: {
					izbor[i].setText("Kompresija porukekoristeci ZIP algoritam");
					break;
				}
				case 3: {
					izbor[i].setText("Konverzija podataka u radix-64 formatu");
					break;
				}
			}
			izbori.add(izbor[i]);
			if (i == 0 || i == 1) {
				int finalI = i;
				izbor[i].addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						ostalo[finalI].setVisible(izbor[finalI].isSelected());
					}
				});
			}

			
		}
	}
}
