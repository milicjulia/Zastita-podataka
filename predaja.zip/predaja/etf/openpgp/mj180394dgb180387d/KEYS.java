package etf.openpgp.mj180394dgb180387d;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Iterator;

import org.bouncycastle.openpgp.PGPException;
import org.bouncycastle.openpgp.PGPPrivateKey;
import org.bouncycastle.openpgp.PGPPublicKey;
import org.bouncycastle.openpgp.PGPPublicKeyRing;
import org.bouncycastle.openpgp.PGPPublicKeyRingCollection;
import org.bouncycastle.openpgp.PGPSecretKey;
import org.bouncycastle.openpgp.PGPSecretKeyRing;
import org.bouncycastle.openpgp.PGPSecretKeyRingCollection;
import org.bouncycastle.openpgp.operator.PBESecretKeyDecryptor;
import org.bouncycastle.openpgp.operator.bc.BcKeyFingerprintCalculator;
import org.bouncycastle.openpgp.operator.bc.BcPBESecretKeyDecryptorBuilder;
import org.bouncycastle.openpgp.operator.bc.BcPGPDigestCalculatorProvider;

public class KEYS {
    public static ArrayList<PGPSecretKeyRing> my_secretKeys=new ArrayList<>();
    public static ArrayList<PGPPublicKeyRing> my_publicKeys=new ArrayList<>();
    public static ArrayList<PGPPublicKeyRing> other_publicKeys=new ArrayList<>();


    public static void saveKeys()throws IOException, PGPException{
        File output_public_file= new File("public.pkr");
        File output_secret_file= new File("secret.skr");
        File output_o_public_file= new File("other_public.pkr");

        FileOutputStream output_public_stream= new FileOutputStream(output_public_file);
        PGPPublicKeyRingCollection publicKeys= new PGPPublicKeyRingCollection(my_publicKeys);
        publicKeys.encode(output_public_stream);

        FileOutputStream output_secret_stream= new FileOutputStream(output_secret_file);
        PGPSecretKeyRingCollection secretKeys= new PGPSecretKeyRingCollection(my_secretKeys);
        secretKeys.encode(output_secret_stream);

        FileOutputStream other_public_stream= new FileOutputStream(output_o_public_file);
        PGPPublicKeyRingCollection otherPublicKeys= new PGPPublicKeyRingCollection(other_publicKeys);
        otherPublicKeys.encode(other_public_stream);
    }
    public static void loadKeys() throws IOException, PGPException {
        File input_public_file= new File("public.pkr");
        File input_secret_file= new File("secret.skr");
        File input_o_public_file= new File("other_public.pkr");

        FileInputStream input_public_stream=new FileInputStream(input_public_file);
        PGPPublicKeyRingCollection importedPublicKeys= new PGPPublicKeyRingCollection(input_public_stream,new BcKeyFingerprintCalculator());

        FileInputStream input_secret_stream=new FileInputStream(input_secret_file);
        PGPSecretKeyRingCollection importedSecretKeys= new PGPSecretKeyRingCollection(input_secret_stream,new BcKeyFingerprintCalculator());

        FileInputStream input_o_public_stream=new FileInputStream(input_o_public_file);
        PGPPublicKeyRingCollection importedOPublicKeys= new PGPPublicKeyRingCollection(input_o_public_stream,new BcKeyFingerprintCalculator());

        Iterator<PGPPublicKeyRing> public_iterator = importedPublicKeys.getKeyRings();
        while(public_iterator.hasNext()){
            my_publicKeys.add(public_iterator.next());
        }

        Iterator<PGPSecretKeyRing> secter_iterator = importedSecretKeys.getKeyRings();
        while(secter_iterator.hasNext()){
            my_secretKeys.add(secter_iterator.next());
        }

        Iterator<PGPPublicKeyRing> o_public_iterator = importedOPublicKeys.getKeyRings();
        while(o_public_iterator.hasNext()){
            other_publicKeys.add(o_public_iterator.next());
        }

    }

    public static ArrayList<PGPSecretKey> get_sign_keys(){
        ArrayList<PGPSecretKey> s_keys=new ArrayList<>();

        for (int i=0;i<my_secretKeys.size();i++){

            Iterator<PGPSecretKey> s_key_iterator=my_secretKeys.get(i).getSecretKeys();

            while(s_key_iterator.hasNext()){
                PGPSecretKey s_key=s_key_iterator.next();

                if(s_key.isSigningKey()){
                    s_keys.add(s_key);
                }
            }

        }
        return s_keys;
    }

    public static ArrayList<PGPPublicKey> get_other_keys(){
        ArrayList<PGPPublicKey> p_keys=new ArrayList<>();

        for (int i=0;i<other_publicKeys.size();i++){

            Iterator<PGPPublicKey> p_key_iterator=other_publicKeys.get(i).getPublicKeys();

            while(p_key_iterator.hasNext()){
                PGPPublicKey p_key=p_key_iterator.next();

           //     if(p_key.isEncryptionKey()){
                    p_keys.add(p_key);
           //    }
            }

        }
        return p_keys;
    }

    public static ArrayList<PGPPublicKey> get_public_keys(){
        ArrayList<PGPPublicKey> p_keys=new ArrayList<>();

        for (int i=0;i<my_publicKeys.size();i++){

            Iterator<PGPPublicKey> p_key_iterator=my_publicKeys.get(i).getPublicKeys();

            while(p_key_iterator.hasNext()){
                PGPPublicKey p_key=p_key_iterator.next();

                if(p_key.isMasterKey()){
                    p_keys.add(p_key);
                }
            }

        }
        return p_keys;
    }

    public static PGPSecretKey findSecretKeyByID(long id){
        for(int i=0;i<my_secretKeys.size();i++){
            PGPSecretKey key=my_secretKeys.get(i).getSecretKey(id);
            if(key!=null)return key;
        }

        return null;
    }
    public static PGPPrivateKey getPrivateKeyFromSecretKey(PGPSecretKey secretKey, char[] pass) {
        try {
            if (secretKey == null) return null;
            PBESecretKeyDecryptor decryptor = new BcPBESecretKeyDecryptorBuilder(
                    new BcPGPDigestCalculatorProvider()).build(pass);
            return secretKey.extractPrivateKey(decryptor);
        }
        catch(PGPException e){
            System.out.println("Pogresna sifra!!!\n");
            return null;
        }
    }

    public static void import_keys_from_file(String filename) throws PGPException, IOException {
        Iterator<PGPPublicKeyRing> ring=IO_KEYS.readPublicKeysFromFile(new File(filename));

        while(ring.hasNext()){
            other_publicKeys.add(ring.next());
        }
    }
    public static PGPPublicKey findPublicKeyByID(long id){

        for (int i = 0; i < other_publicKeys.size(); i++) {
            PGPPublicKey key = other_publicKeys.get(i).getPublicKey(id);
            if (key != null) return key;
        }
        return null;
    }
    
    public static PGPSecretKeyRing getSecretKeyRing(long id) {
    	for(int i=0;i<my_secretKeys.size();i++) {
    		PGPSecretKey secret=my_secretKeys.get(i).getSecretKey(id);
    		if(secret!=null) return my_secretKeys.get(i);
    	}
    	return null;
    }
    
    public static PGPPublicKeyRing getPublicKeyRing(long id) {
    	for(int i=0;i<my_publicKeys.size();i++) {
    		PGPPublicKey publicK=my_publicKeys.get(i).getPublicKey(id);
    		if(publicK!=null) return my_publicKeys.get(i);
    	}
    	return null;
    }

    public static PGPPublicKeyRing get_public_key_ring(PGPPublicKey pkey){
        long id=pkey.getKeyID();
        for(int i=0;i<my_publicKeys.size();i++) {
            PGPPublicKey publicK=my_publicKeys.get(i).getPublicKey(id);
            if(publicK!=null) return my_publicKeys.get(i);
        }
        return null;
    }

     public static int deletePrivateKey(PGPSecretKey skey, char[] password){
        PGPPrivateKey privateKeyFromSecretKey = getPrivateKeyFromSecretKey(skey, password);
        if(privateKeyFromSecretKey==null) return -1;
        else{
            int i;
            for ( i=0;i<my_secretKeys.size();i++){
                if(my_secretKeys.get(i).getSecretKey(skey.getKeyID())!=null)break;
            }
            my_secretKeys.remove(i);
            for ( i=0;i<my_publicKeys.size();i++){
                if(my_publicKeys.get(i).getPublicKey(skey.getKeyID())!=null)break;
            }
            my_publicKeys.remove(i);
        }

        return 0;
    }

    public static int deleteOtherKey(PGPPublicKey skey){
        int i;
        for ( i=0;i<other_publicKeys.size();i++){
            if(other_publicKeys.get(i).getPublicKey(skey.getKeyID())!=null)break;
        }
        other_publicKeys.remove(i);

        return 0;
    }


}
