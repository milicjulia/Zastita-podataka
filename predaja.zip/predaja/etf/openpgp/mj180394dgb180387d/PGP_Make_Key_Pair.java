package etf.openpgp.mj180394dgb180387d;

import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.Date;

import org.bouncycastle.bcpg.HashAlgorithmTags;
import org.bouncycastle.bcpg.SymmetricKeyAlgorithmTags;
import org.bouncycastle.bcpg.sig.Features;
import org.bouncycastle.bcpg.sig.KeyFlags;
import org.bouncycastle.crypto.generators.DSAKeyPairGenerator;
import org.bouncycastle.crypto.generators.ElGamalKeyPairGenerator;
import org.bouncycastle.crypto.params.DSAKeyGenerationParameters;
import org.bouncycastle.crypto.params.DSAParameters;
import org.bouncycastle.crypto.params.ElGamalKeyGenerationParameters;
import org.bouncycastle.crypto.params.ElGamalParameters;
import org.bouncycastle.openpgp.PGPEncryptedData;
import org.bouncycastle.openpgp.PGPException;
import org.bouncycastle.openpgp.PGPKeyPair;
import org.bouncycastle.openpgp.PGPKeyRingGenerator;
import org.bouncycastle.openpgp.PGPPublicKey;
import org.bouncycastle.openpgp.PGPSignature;
import org.bouncycastle.openpgp.PGPSignatureSubpacketGenerator;
import org.bouncycastle.openpgp.operator.PBESecretKeyEncryptor;
import org.bouncycastle.openpgp.operator.PGPDigestCalculator;
import org.bouncycastle.openpgp.operator.bc.BcPBESecretKeyEncryptorBuilder;
import org.bouncycastle.openpgp.operator.bc.BcPGPContentSignerBuilder;
import org.bouncycastle.openpgp.operator.bc.BcPGPDigestCalculatorProvider;
import org.bouncycastle.openpgp.operator.bc.BcPGPKeyPair;

public class PGP_Make_Key_Pair {

    public final static  PGPKeyRingGenerator make_key_ring(String name,String email, char[] password, int dsa_key_size,int elgamal_key_size) throws PGPException {

        DSAKeyPairGenerator dsa_kpg= new DSAKeyPairGenerator();



        dsa_kpg.init(new DSAKeyGenerationParameters(new SecureRandom(),new DSAParameters(new BigInteger("123214"),new BigInteger("123214"),new BigInteger("123214"))));
        ElGamalKeyPairGenerator elgamal_kpg=new ElGamalKeyPairGenerator();

        elgamal_kpg.init(new ElGamalKeyGenerationParameters(new SecureRandom(),new ElGamalParameters(new BigInteger("123214"),new BigInteger("123214"))));

        PGPKeyPair dsaKpSign =new BcPGPKeyPair(PGPPublicKey.DSA,dsa_kpg.generateKeyPair(),new Date());
        PGPKeyPair elgamalKpEncryp = new BcPGPKeyPair(PGPPublicKey.ELGAMAL_ENCRYPT,elgamal_kpg.generateKeyPair(),new Date());


        PGPSignatureSubpacketGenerator pgp_ssg_sign = new PGPSignatureSubpacketGenerator();

        pgp_ssg_sign.setKeyFlags(false, KeyFlags.SIGN_DATA| KeyFlags.CERTIFY_OTHER);

        pgp_ssg_sign.setPreferredSymmetricAlgorithms(false, new int[] {
                SymmetricKeyAlgorithmTags.TRIPLE_DES,
                SymmetricKeyAlgorithmTags.IDEA
        });
        pgp_ssg_sign.setPreferredHashAlgorithms(false, new int[] {
                HashAlgorithmTags.SHA1
        });

        pgp_ssg_sign.setFeature(false, Features.FEATURE_MODIFICATION_DETECTION);


        PGPSignatureSubpacketGenerator pgp_ssg_encrypt = new PGPSignatureSubpacketGenerator();
        pgp_ssg_encrypt.setKeyFlags(false, KeyFlags.ENCRYPT_COMMS| KeyFlags.ENCRYPT_STORAGE);

        PGPDigestCalculator sha1Calc = new BcPGPDigestCalculatorProvider().get(HashAlgorithmTags.SHA1);


        final int s2kCount = 0xc0;
        PBESecretKeyEncryptor pskEnc =
                (new BcPBESecretKeyEncryptorBuilder(PGPEncryptedData.AES_256, sha1Calc, s2kCount)).build(password);


        PGPKeyRingGenerator pgp_krg=new PGPKeyRingGenerator(PGPSignature.POSITIVE_CERTIFICATION,dsaKpSign,name+";"+email,sha1Calc,pgp_ssg_sign.generate(),null,new BcPGPContentSignerBuilder(dsaKpSign.getPublicKey().getAlgorithm(),HashAlgorithmTags.SHA1),pskEnc);
        pgp_krg.addSubKey(elgamalKpEncryp,pgp_ssg_encrypt.generate(),null);

        return pgp_krg;
    }

}
