package etf.openpgp.mj180394dgb180387d;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.security.Provider;
import java.security.SecureRandom;
import java.security.Security;
import java.util.Date;
import java.util.Iterator;

//import netscape.security.UserTarget;
import org.bouncycastle.bcpg.ArmoredOutputStream;
import org.bouncycastle.bcpg.HashAlgorithmTags;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openpgp.PGPCompressedData;
import org.bouncycastle.openpgp.PGPCompressedDataGenerator;
import org.bouncycastle.openpgp.PGPEncryptedData;
import org.bouncycastle.openpgp.PGPEncryptedDataGenerator;
import org.bouncycastle.openpgp.PGPLiteralData;
import org.bouncycastle.openpgp.PGPLiteralDataGenerator;
import org.bouncycastle.openpgp.PGPPrivateKey;
import org.bouncycastle.openpgp.PGPPublicKey;
import org.bouncycastle.openpgp.PGPSecretKey;
import org.bouncycastle.openpgp.PGPSignature;
import org.bouncycastle.openpgp.PGPSignatureGenerator;
import org.bouncycastle.openpgp.PGPSignatureSubpacketGenerator;
import org.bouncycastle.openpgp.operator.PGPContentSignerBuilder;
import org.bouncycastle.openpgp.operator.bc.BcPGPContentSignerBuilder;
import org.bouncycastle.openpgp.operator.bc.BcPGPDataEncryptorBuilder;
import org.bouncycastle.openpgp.operator.bc.BcPublicKeyKeyEncryptionMethodGenerator;

public class Encrypt {

    static public int RADIX64_FLAG=1;
 //   static public int HASH_FLAG=2;
    static public int SIGN_FLAG=4;
    static public int ENCRYPT_FLAG=8;
    static public int COMPRESS_FLAG=16;

    static public int TRIPLE_DES_ENCRYPT_FLAG=32;
    static public int IDEA_ENCRYPT_FLAG=0;

    //NET
    public static void signEncryptFile(
            String fileName,
            PGPPublicKey publicKey,
            PGPSecretKey secretKey,
            char[] password,
            int flags, String outputfilepath)
            throws Exception
    {

        // Initialize Bouncy Castle security provider
        Provider provider = new BouncyCastleProvider();
        Security.addProvider(provider);
        OutputStream out = new FileOutputStream(outputfilepath+".pgp");
        //RADIX64
        if ((flags&RADIX64_FLAG)!=0) {
            out = new ArmoredOutputStream(out);
        }

        // ENCRYPT
        BcPGPDataEncryptorBuilder dataEncryptor;
        OutputStream encryptedOut = out;
        PGPEncryptedDataGenerator encryptedDataGenerator = null;

        if ((flags&ENCRYPT_FLAG)!=0) {
            if ((flags&TRIPLE_DES_ENCRYPT_FLAG)!=0) {
                dataEncryptor = new BcPGPDataEncryptorBuilder(PGPEncryptedData.TRIPLE_DES);
            }
            else {
                dataEncryptor = new BcPGPDataEncryptorBuilder(PGPEncryptedData.IDEA);
            }
            dataEncryptor.setWithIntegrityPacket(true);
            dataEncryptor.setSecureRandom(new SecureRandom());

            encryptedDataGenerator = new PGPEncryptedDataGenerator(dataEncryptor);

            if (publicKey != null) {
                encryptedDataGenerator.addMethod(new BcPublicKeyKeyEncryptionMethodGenerator(publicKey));
                encryptedOut = encryptedDataGenerator.open(out, new byte[1<<16]);
            }
        }

        // COMPRESS
        PGPCompressedDataGenerator compressedDataGenerator =
                new PGPCompressedDataGenerator(((flags&COMPRESS_FLAG)!=0) ? PGPCompressedData.ZIP : PGPCompressedData.UNCOMPRESSED);
        OutputStream compressedOut = compressedDataGenerator.open(encryptedOut, new byte [1<<16]);

        // SIGN
        PGPSignatureGenerator signatureGenerator = null;

        if ((flags&SIGN_FLAG)!=0) {

            PGPPrivateKey privateKey = KEYS.getPrivateKeyFromSecretKey(secretKey, password);
            PGPContentSignerBuilder signerBuilder = new BcPGPContentSignerBuilder(secretKey.getPublicKey().getAlgorithm(),
                    HashAlgorithmTags.SHA1);
            signatureGenerator = new PGPSignatureGenerator(signerBuilder);
            signatureGenerator.init(PGPSignature.BINARY_DOCUMENT, privateKey);

            Iterator<String> it = secretKey.getPublicKey().getUserIDs();
            if (it.hasNext()) {
                PGPSignatureSubpacketGenerator spGen = new PGPSignatureSubpacketGenerator();
                //noinspection deprecation
                spGen.setSignerUserID(false, it.next());
                signatureGenerator.setHashedSubpackets(spGen.generate());
            }
            signatureGenerator.generateOnePassVersion(false).encode(compressedOut);
        }

        // Initialize literal data generator
        PGPLiteralDataGenerator literalDataGenerator = new PGPLiteralDataGenerator();
        OutputStream literalOut = literalDataGenerator.open(
                compressedOut,
                PGPLiteralData.BINARY,
                fileName,
                new Date(),
                new byte [1<<16] );

        // Main loop - read the "in" stream, compress, encrypt and write to the "out" stream
        FileInputStream in = new FileInputStream(fileName);
        byte[] buf = new byte[1<<16];
        int len;
        while ((len = in.read(buf)) > 0) {//ako je fajl veci od 1<<16 ova petlja ce vise puta da se odradi
            literalOut.write(buf, 0, len);
            if ((flags&SIGN_FLAG)!=0)
                signatureGenerator.update(buf, 0, len);
        }

        in.close();
        literalDataGenerator.close();
        // Generate the signature, compress, encrypt and write to the "out" stream
        if ((flags&SIGN_FLAG)!=0) {
            signatureGenerator.generate().encode(compressedOut);

        }
        if ((flags&COMPRESS_FLAG)!=0)
            compressedDataGenerator.close();
        if ((flags&ENCRYPT_FLAG)!=0)
            encryptedDataGenerator.close();
        out.close();
    }


}
