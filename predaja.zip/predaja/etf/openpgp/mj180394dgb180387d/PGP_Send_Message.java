package etf.openpgp.mj180394dgb180387d;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.security.GeneralSecurityException;
import java.security.PrivateKey;
import java.security.Signature;
import java.util.Iterator;

import org.bouncycastle.bcpg.ArmoredOutputStream;
import org.bouncycastle.openpgp.PGPCompressedData;
import org.bouncycastle.openpgp.PGPCompressedDataGenerator;
import org.bouncycastle.openpgp.PGPEncryptedData;
import org.bouncycastle.openpgp.PGPException;
import org.bouncycastle.openpgp.PGPPrivateKey;
import org.bouncycastle.openpgp.PGPSecretKey;
import org.bouncycastle.openpgp.PGPSignature;
import org.bouncycastle.openpgp.PGPSignatureGenerator;
import org.bouncycastle.openpgp.PGPSignatureSubpacketGenerator;
import org.bouncycastle.openpgp.PGPUtil;
import org.bouncycastle.openpgp.operator.bc.BcPGPContentSignerBuilder;
import org.bouncycastle.openpgp.operator.bc.BcPGPDataEncryptorBuilder;
import org.bouncycastle.openpgp.operator.jcajce.JcaPGPContentSignerBuilder;

public class PGP_Send_Message {

    static public int RADIX64_FLAG=1;
    static public int HASH_FLAG=2;
    static public int SIGN_FLAG=4;
    static public int ENCRYPT_FLAG=8;

    static public int TRIPLE_DES_ENCRYPT_FLAG=16;
    static public int IDEA_ENCRYPT_FLAG=0;

    private int status;
    public PGP_Send_Message(int flags){
        status=flags;
    }

    public static byte[] generateSignature(PrivateKey dsaPrivate, byte[] input)
            throws GeneralSecurityException {
        Signature signature = Signature.getInstance("SHA1withDSA", "BCFIPS");
        signature.initSign(dsaPrivate);
        signature.update(input);
        return signature.sign();
    }

    public static void generate_Signature(PGPSecretKey pgp_sk,PGPPrivateKey pgp_pk) throws PGPException {

        PGPSignatureGenerator sGen = new PGPSignatureGenerator(new JcaPGPContentSignerBuilder(pgp_sk.getPublicKey().getAlgorithm(), PGPUtil.SHA1).setProvider("BC"));

        sGen.init(PGPSignature.BINARY_DOCUMENT, pgp_pk);

        Iterator it = pgp_sk.getPublicKey().getUserIDs();
        if (it.hasNext()) {
            PGPSignatureSubpacketGenerator spGen = new PGPSignatureSubpacketGenerator();

            spGen.setSignerUserID(false, (String) it.next());
            sGen.setHashedSubpackets(spGen.generate());
        }

        PGPCompressedDataGenerator cGen = new PGPCompressedDataGenerator(
                PGPCompressedData.UNCOMPRESSED);

    }



    public void send(PGPPrivateKey priv_key, File message_file, File output_file) throws FileNotFoundException {

        //sign
        try {
            if ((SIGN_FLAG & status) != 0) {

                PGPSignatureGenerator pgp_sign_gen = new PGPSignatureGenerator(new BcPGPContentSignerBuilder(priv_key.getPublicKeyPacket().getAlgorithm(), PGPUtil.SHA1));
                pgp_sign_gen.init(PGPSignature.BINARY_DOCUMENT, priv_key);
                PGPSignature pgp_sign=pgp_sign_gen.generate();
           //     pgp_sign.
            }
        }
        catch (PGPException e){
            e.printStackTrace();
        }
        //encrypt

        if((ENCRYPT_FLAG&status)!=0){

            BcPGPDataEncryptorBuilder pgp_deb;
            if((TRIPLE_DES_ENCRYPT_FLAG&status)==0){
                pgp_deb=new BcPGPDataEncryptorBuilder(PGPEncryptedData.IDEA);
            }
            else {
                pgp_deb=new BcPGPDataEncryptorBuilder(PGPEncryptedData.TRIPLE_DES);
            }

        }

        //hash
        PGPCompressedDataGenerator pgp_cdg=new PGPCompressedDataGenerator(PGPCompressedData.ZIP);

        OutputStream output_file_stream = new FileOutputStream(output_file);

        if((RADIX64_FLAG&status)!=0){
            output_file_stream= new ArmoredOutputStream(output_file_stream);
        }


    }

}
